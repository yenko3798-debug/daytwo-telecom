

  export function Footer() {
    return (
      <footer className="mt-32 flex-none">

      </footer>
    )
  }
